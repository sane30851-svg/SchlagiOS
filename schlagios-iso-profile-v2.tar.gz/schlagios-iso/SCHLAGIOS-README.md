# SchlagiOS ISO bauen (v2, ungetestet)

Auf CachyOS/Arch, als normaler Benutzer, im Ordner schlagios-iso:

    sudo pacman -S --needed archiso mkinitcpio-archiso git squashfs-tools grub base-devel paru
    ./aur-repo/build-aur-repo.sh      # baut Caelestia, claude-code, schlagios-branding in ein lokales Repo
    sudo ./buildiso.sh -v -w          # Profil "schlagios" ist Standard

ISO: out/schlagios/schlagios-linux-<datum>.iso

Live: Autologin -> Hyprland -> Caelestia Shell, SchlagiOS-Hintergrund, Fastfetch mit ASCII-Art.
Claude: Eintraege "Claude (Terminal)" und "Claude (Web)" im Caelestia-Launcher, Taste SUPER+C (ungeprueft).
Beim ersten Start in "claude" einloggen.

Installer: SchlagiOS-Branding (/etc/calamares/branding/cachyos), Plymouth-Theme "schlagios",
Zusatzgruppen Slicer/CAD (nur Standard-Repos).

Offen: Hyprland + Caelestia auf dem INSTALLIERTEN System (braucht gehostetes Repo fuer AUR-Pakete),
Orca/Bambu/OnlyOffice im Installer, Bootanimation in der Live-Sitzung.
