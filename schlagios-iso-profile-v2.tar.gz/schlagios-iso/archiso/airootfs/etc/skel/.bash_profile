#
# ~/.bash_profile
#
[[ -f ~/.bashrc ]] && . ~/.bashrc

# SchlagiOS: auf tty1 direkt Hyprland (mit Caelestia Shell) starten
if [[ -z $WAYLAND_DISPLAY && -z $DISPLAY && ${XDG_VTNR:-1} -eq 1 ]]; then
    exec Hyprland
fi
