-- SchlagiOS: Standard-Hintergrund beim ersten Start setzen
hl.exec_cmd("sh -c 'sleep 5; [ -f $HOME/.local/state/schlagios/wallpaper-set ] || { caelestia wallpaper -f /usr/share/backgrounds/schlagios/schlagios-wallpaper.png && mkdir -p $HOME/.local/state/schlagios && touch $HOME/.local/state/schlagios/wallpaper-set; }'")

-- Claude: SUPER + C oeffnet Claude Code im Terminal (nur wenn die API so existiert)
pcall(function()
    hl.bind("SUPER + C", hl.dsp.exec_cmd("foot -e claude"))
end)
