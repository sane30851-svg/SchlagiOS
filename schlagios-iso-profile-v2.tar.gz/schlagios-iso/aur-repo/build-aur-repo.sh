#!/usr/bin/env bash
# Baut die AUR-Pakete fuer SchlagiOS und legt sie in ein lokales pacman-Repo (aur-repo/x86_64).
# Als NORMALER Benutzer ausfuehren (nicht root), auf CachyOS/Arch mit paru und base-devel.
set -euo pipefail
cd "$(dirname "$0")"

[ "$EUID" -ne 0 ] || { echo "Bitte NICHT als root ausfuehren."; exit 1; }
command -v paru >/dev/null || { echo "paru fehlt. Auf CachyOS: sudo pacman -S paru"; exit 1; }

# Pakete, die nicht in den normalen Repos sind (Abhaengigkeiten aus dem AUR werden von paru mitgebaut)
PKGS=(caelestia-shell caelestia-cli quickshell-git qt6-m3shapes-git ttf-material-symbols-variable ttf-rubik-vf claude-code)

mkdir -p x86_64
paru -S --needed --noconfirm "${PKGS[@]}"

# Eigenes Branding-Paket bauen
( cd ../packages/schlagios-branding && makepkg -f --noconfirm && cp -f schlagios-branding-*.pkg.tar.zst ../../aur-repo/x86_64/ )

# Alle gebauten Pakete (inkl. AUR-Abhaengigkeiten) einsammeln
find "${XDG_CACHE_HOME:-$HOME/.cache}/paru/clone" -name '*.pkg.tar.zst' ! -name '*-debug-*' -exec cp -u {} x86_64/ \;

rm -f x86_64/schlagios-local.db* x86_64/schlagios-local.files*
repo-add x86_64/schlagios-local.db.tar.gz x86_64/*.pkg.tar.zst
echo "Fertig: $(ls x86_64/*.pkg.tar.zst | wc -l) Pakete im lokalen Repo."
